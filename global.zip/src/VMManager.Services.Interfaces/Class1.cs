﻿namespace VMManager.Services.Interfaces;

public class Class1
{

}
