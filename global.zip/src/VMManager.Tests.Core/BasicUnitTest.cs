
using Xunit;

namespace VMManager.Tests
{
    public class BasicUnitTest
    {
        [Fact]
        public void SampleTest()
        {
            Assert.True(1 + 1 == 2);
        }
    }
}
